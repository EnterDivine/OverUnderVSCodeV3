#include "main.h"
#include "autoSelect/selection.h"
#include "okapi/api.hpp"
#include <iostream>
#include <future>
using namespace okapi;

/**
 * Testing ground for Okapilib
 *
 * Mostly to see if it's best to use Okapilib for Odom and chassis setup or to make your own.
 */
auto chassis = ChassisControllerBuilder()
				   .withMotors({-1, -3, 5}, {16, -18, 20})
				   /**
					* ONLY COMMENT OUT BELOW IF NEEDED
					*/
				   //
				   //    .withGains(
				   // 	   {0.001, 0, 0.0001},		// Distance controller gains
				   // 	   {0.0001, 0.001, 0.0002}, // Turn controller gains. Second is speed, third is oscillation frequency, first... IDFK
				   // 	   {0.001, 0, 0.0001}		// Angle controller gains (helps drive straight)
				   // 	   )
				   .withDimensions(AbstractMotor::gearset::green, {{4_in, 11.5_in}, imev5GreenTPR})
				   .build();

pros::Motor Intake(-10);
pros::Motor LB(7);
pros::Rotation LBR(9);

Controller controller;

pros::ADIDigitalOut pneumatics('A', false);

void initialize()
{
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Drivetrain (Odom)");
	selector::init();
}

/**
 *
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */

void autonomous()
{
	if (selector::auton == 1)
	{
		LBR.set_position(1000);
		// Run Lady Bornw to place ring in alliance stake
		LB.move_relative(1170, 200);
		while (!((LB.get_position() < 1170 + 5) && (LB.get_position() > 1170 - 5)))
		{
			// Continue running this loop as long as the motor is not within +-5 units of its goal
			pros::delay(2);
		}
		pros::delay(1000);
		LB.move_relative(0, 200);
		while (!((LB.get_position() < 0 + 5) && (LB.get_position() > 0 - 5)))
		{
			// Continue running this loop as long as the motor is not within +-5 units of its goal
			pros::delay(2);
		}
		// Move to get mobile goal
		chassis->setMaxVelocity(1200 / 12.5);
		chassis->moveDistance(-38_in);
		pneumatics.set_value(true);
		// Get ring
		chassis->turnAngle(-20_deg);
		// Load Ring
		Intake.move(200);
		chassis->moveDistance(38_in);
		pros::delay(2000);
		Intake.move(0);
		// ???
		/// Profit
	}
	if (selector::auton == 2)
	{
		/*Code auton for Far Red */
		// chassis->turnAngle(90_deg);
		// chassis->turnAngle(-90_deg);
		// chassis->moveDistance(-2_ft);
		// pneumatics.set_value(false);
		// Intake.move(127 * 2);
		// pros::delay(1000);
		// Intake.move(0);
		// chassis->moveDistance(6_in);
		// chassis->turnAngle(45_deg);
		// chassis->moveDistance(-10_in);
		// chassis->turnAngle(-22.5_deg);
		// chassis->moveDistance(-1.5_ft);
	}
	if (selector::auton == 3)
	{
		/*Code auton for Red Nothing (Leave Blank) */
	}
	if (selector::auton == -1)
	{
		/*Code auton for Near Blue */
	}
	if (selector::auton == -2)
	{
		/*Code auton for Far Blue */
	}
	if (selector::auton == -3)
	{
		/*Code auton for Blue Nothing (Leave Blank) */
	}
	if (selector::auton == 0)
	{
		/*Code Skills*/
		pros::delay(45000);
	}
}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol()
{
	pros::Controller Controller(CONTROLLER_MASTER);
	LBR.set_position(0);
	LB.set_zero_position(0);
	bool isLoading = false;
	while (true)
	{
		chassis->setMaxVelocity(1200);
		/* Code User Control*/
		chassis->getModel()->arcade(controller.getAnalog(ControllerAnalog::leftY),
									controller.getAnalog(ControllerAnalog::rightX));

		if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT))
		{
			Intake.move(250);
		}
		else if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_Y))
		{
			Intake.move(-250);
		}
		else
		{
			Intake.move(0);
		}

		if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1))
		{
			pneumatics.set_value(false);
		}
		else if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2))
		{
			pneumatics.set_value(true);
		}

		if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2))
		{
			LB.move_absolute(110, 200);
		}
		if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_A))
		{
			LB.move_absolute(1370, 200);
		}
		if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1))
		{
			LB.move_absolute(0, 200);
		}

		// if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2))
		// {
		// 	LB.move(200);
		// }
		// else if (Controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1))
		// {
		// 	LB.move(-200);
		// }
		// else
		// {
		// 	LB.move(0);
		// }
	}

	pros::delay(20);
}
